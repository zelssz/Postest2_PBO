/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.koleksifashion.service;

/**
 *
 * @author userrr
 */
import com.mycompany.koleksifashion.model.Item;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FashionService {
    private final List<Item> katalog = new ArrayList<>();
    private int nextId = 1;

    public FashionService() { seed10Item(); }

    // CREATE
    public Item tambah(String nama, String kategori, String ukuran, String warna, String brand, int tahun) {
        Item it = new Item(nextId++, nama, kategori, ukuran, warna, brand, tahun);
        katalog.add(it);
        return it;
    }

    // READ
    public List<Item> semua() { return Collections.unmodifiableList(katalog); }
    public Item byId(int id) { return katalog.stream().filter(i -> i.getId() == id).findFirst().orElse(null); }

    // UPDATE
    public boolean update(int id, String nama, String kategori, String ukuran, String warna, String brand, Integer tahun) {
        Item it = byId(id);
        if (it == null) return false;
        if (nama != null && !nama.isBlank()) it.setNama(nama);
        if (kategori != null && !kategori.isBlank()) it.setKategori(kategori);
        if (ukuran != null && !ukuran.isBlank()) it.setUkuran(ukuran);
        if (warna != null && !warna.isBlank()) it.setWarna(warna);
        if (brand != null && !brand.isBlank()) it.setBrand(brand);
        if (tahun != null && tahun >= 0) it.setTahun(tahun);
        return true;
    }

    // DELETE
    public boolean hapus(int id) {
        Item it = byId(id);
        return it != null && katalog.remove(it);
    }

    // SEARCH (ID atau Nama)
    public List<Item> cari(String q) {
        if (q == null || q.isBlank()) return List.of();
        try {
            int id = Integer.parseInt(q.trim());
            Item it = byId(id);
            return it == null ? List.of() : List.of(it);
        } catch (NumberFormatException e) {
            String s = q.toLowerCase();
            return katalog.stream()
                    .filter(i -> i.getNama().toLowerCase().contains(s))
                    .collect(Collectors.toList());
        }
    }

    // FILTER
    public List<Item> filterKategori(String kategori) {
        return katalog.stream()
                .filter(i -> i.getKategori().equalsIgnoreCase(kategori))
                .collect(Collectors.toList());
    }

    // Seed data awal
    private void seed10Item() {
        tambah("Jaket Denim","Outer","M","Navy","Levi's",2022);
        tambah("Sneakers Canvas","Sepatu","42","Putih","Converse",2021);
        tambah("Kaos Graphic","Atasan","L","Hitam","Uniqlo",2023);
        tambah("Celana Chino","Bawahan","32","Khaki","H&M",2022);
        tambah("Dress Batik","Atasan","M","Maroon","Lokal",2023);
        tambah("Hoodie Oversize","Outer","L","Abu","Zara",2024);
        tambah("Topi Bucket","Aksesori","All Size","Cream","Columbia",2020);
        tambah("Rok Plisket","Bawahan","M","Dusty Pink","Stradivarius",2023);
        tambah("Cardigan Rajut","Outer","S","Hijau","Pull&Bear",2021);
        tambah("Loafers Kulit","Sepatu","41","Cokelat","Pedro",2022);
    }
}
