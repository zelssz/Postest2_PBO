/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.koleksifashion.model;

public class Item {
    // properties (private)
    private int id;
    private String nama;
    private String kategori;
    private String ukuran;
    private String warna;
    private String brand;
    private int tahun;

    // constructor
    public Item(int id, String nama, String kategori, String ukuran, String warna, String brand, int tahun) {
        this.id = id;
        this.nama = nama;
        this.kategori = kategori;
        this.ukuran = ukuran;
        this.warna = warna;
        this.brand = brand;
        this.tahun = tahun;
    }

    // getter & setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getUkuran() { return ukuran; }
    public void setUkuran(String ukuran) { this.ukuran = ukuran; }

    public String getWarna() { return warna; }
    public void setWarna(String warna) { this.warna = warna; }

    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public int getTahun() { return tahun; }
    public void setTahun(int tahun) { this.tahun = tahun; }
}
